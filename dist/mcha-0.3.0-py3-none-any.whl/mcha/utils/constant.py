IMAGE_BASE_PATH = "/mnt/data2/bingkui/MCHA_experiments/dataset/images/"
NOISE_IMAGE_PATH = "/mnt/data2/bingkui/MCHA_experiments/dataset/noise.png"
NOT_REASONING_POST_PROMPT = "\nPlease respond with only the letter of the correct choice (A, B, C, D, or E). Do not include the option text or any other explanation."
IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD = (0.229, 0.224, 0.225)